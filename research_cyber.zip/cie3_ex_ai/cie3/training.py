import pandas as pd
import pickle
import numpy as np
from math import sqrt
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
from sklearn.neural_network import MLPRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
import shap
import matplotlib.pyplot as plt
import os

# === Configuration ===

# Define columns to match Flask App
# This is the single source of truth for features.
REQUIRED_COLS = ['AGE', 'INCOME', 'EMPLOYMENT_STATUS', 'LOAN_AMOUNT', 'LOAN_TERM',
                 'INTEREST_RATE', 'NUM_OF_DEPENDENTS', 'MARITAL_STATUS', 'EDUCATION_LEVEL']
TARGET_COL = 'CREDIT_SCORE'

# Output static folder for web app
STATIC_FOLDER = "static"
os.makedirs(STATIC_FOLDER, exist_ok=True)


# === STEP 1: Load Dataset ===
train_file = r"C:\Users\divya\Downloads\research_cyber\research_cyber\cie3\credit_score_training_data.xlsx"
df = pd.read_excel(train_file)

# Encode categorical features
label_encoders = {}
all_categorical_cols = df.select_dtypes(include=['object']).columns

for col in all_categorical_cols:
    le = LabelEncoder()
    # Fit transform on the entire column to learn all possible categories
    df[col] = le.fit_transform(df[col])
    
    # Only save encoders for columns we actually use
    if col in REQUIRED_COLS:
        label_encoders[col] = le

# Split into features and target variable
# Use *only* the required columns for features
try:
    X = df[REQUIRED_COLS]
    y = df[TARGET_COL]
except KeyError as e:
    print(f"🔥 ERROR: A required column is missing from the Excel file: {e}")
    print("Please check your REQUIRED_COLS list and the Excel file.")
    exit()


# === STEP 2: Define Models to Compare ===
models_to_try = {
    "RandomForest": lambda seed: RandomForestRegressor(random_state=seed),
    "GradientBoosting": lambda seed: GradientBoostingRegressor(random_state=seed),
    "MLPRegressor": lambda seed: MLPRegressor(hidden_layer_sizes=(64, 32), max_iter=500, random_state=seed)
}

# === STEP 3: Train and Evaluate Models ===
best_r2 = float('-inf')
best_model = None
best_model_name = ""
best_scaler = None
best_comparison_df = None
best_epoch = None
best_X_train = None
best_X_test = None
best_y_train = None
best_y_test = None
best_X_train_df = None # To store the scaled DataFrame for SHAP

for model_name, model_func in models_to_try.items():
    print(f"\nTraining model: {model_name}")

    for epoch in range(1, 21):
        # Split dataset
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=0.2, random_state=epoch
        )

        # Scale features
        scaler = StandardScaler()
        X_train_scaled = scaler.fit_transform(X_train)
        X_test_scaled = scaler.transform(X_test)

        # Train model
        model = model_func(epoch)
        model.fit(X_train_scaled, y_train)

        # Predict
        y_pred = model.predict(X_test_scaled)

        # Evaluate
        mae = mean_absolute_error(y_test, y_pred)
        mse = mean_squared_error(y_test, y_pred)
        rmse = sqrt(mse)
        r2 = r2_score(y_test, y_pred)

        print(f"Epoch {epoch:2d} | R²: {r2:.4f} | RMSE: {rmse:.2f} | MAE: {mae:.2f}")

        # Save best model
        if r2 > best_r2:
            best_r2 = r2
            best_model = model
            best_model_name = model_name
            best_scaler = scaler
            best_epoch = epoch
            best_comparison_df = pd.DataFrame({
                'Actual': y_test.values,
                'Predicted': y_pred.round(2)
            })
            best_X_train, best_X_test = X_train_scaled, X_test_scaled
            best_y_train, best_y_test = y_train, y_test
            # Save the scaled training data as a DataFrame
            best_X_train_df = pd.DataFrame(best_X_train, columns=REQUIRED_COLS)

# === STEP 4: Save Model, Encoders, and SHAP Data ===
with open("credit_score_model.pkl", "wb") as f:
    pickle.dump(best_model, f)
with open("scaler.pkl", "wb") as f:
    pickle.dump(best_scaler, f)
with open("encoders.pkl", "wb") as f:
    pickle.dump(label_encoders, f)

# --- ADD THIS SECTION ---
# Save model info and background data for SHAP
print("\n💾 Saving SHAP background data and model info...")
model_info = {
    'model_name': best_model_name,
    'feature_names': REQUIRED_COLS
}
with open("model_info.pkl", "wb") as f:
    pickle.dump(model_info, f)

# Save the scaled training data (as a DataFrame) for background
best_X_train_df.to_pickle("shap_background_data.pkl")
# --- END ADD ---

print("\n✅ Best model, scaler, encoders, and SHAP data saved.")
print(f"🏆 Best Model: {best_model_name} (epoch {best_epoch})")
print(f"📈 Best R² Score: {best_r2:.4f}")
print("\n📊 Sample Prediction Results:")
print(best_comparison_df.head(10))

# === STEP 5: Explainability with SHAP ===
print("\n🔍 Generating Explainable AI (XAI) Visuals using SHAP...")

# Convert test data back to DataFrame for interpretability
X_test_df = pd.DataFrame(best_X_test, columns=REQUIRED_COLS)

# Use the saved background data for the explainer for consistency
# Sample it for speed, as the app will do
background_data_sample = shap.sample(best_X_train_df, 100)

# Initialize the SHAP Explainer
# This unified interface works for all model types
explainer = shap.Explainer(best_model, background_data_sample)

# Calculate SHAP values for the test set
# --- THIS IS THE FIX ---
shap_values = explainer(X_test_df, check_additivity=False)
# --- END FIX ---


# === STEP 6: Visual Explanations ===
print(f"Generating and saving SHAP plots to '{STATIC_FOLDER}/' folder...")

# --- Global Feature Importance (Bar Plot) ---
plt.figure()
shap.summary_plot(shap_values, X_test_df, plot_type="bar", show=False)
plt.title(f"Global Feature Importance ({best_model_name})")
plt.tight_layout()
# Save to static folder
plt.savefig(os.path.join(STATIC_FOLDER, "shap_global_importance.png"), dpi=300)
plt.close()

# --- Detailed Summary Plot (Beeswarm) ---
plt.figure()
shap.summary_plot(shap_values, X_test_df, show=False)
plt.title(f"Detailed SHAP Summary ({best_model_name})")
plt.tight_layout()
# Save to static folder
plt.savefig(os.path.join(STATIC_FOLDER, "shap_summary_plot.png"), dpi=300)
plt.close()

# --- Sample Local Explanation (Waterfall) ---
# This is just for your own confirmation
sample_idx = 0
plt.figure()
shap.plots.waterfall(shap_values[sample_idx], show=False)
plt.title("SHAP Waterfall Plot for One Prediction (Sample)")
plt.tight_layout()
plt.savefig(os.path.join(STATIC_FOLDER, "shap_local_explanation_sample.png"), dpi=300)
plt.close()

print(f"✅ SHAP plots saved to '{STATIC_FOLDER}/' folder.")