from PIL import Image
import numpy as np
import hashlib

# Load image
img = Image.open(r"C:\Users\divya\Downloads\team_25\team_25\static\bank_logo.jpg")
arr = np.array(img)

# Safely bump 1 pixel channel
arr = arr.astype(np.uint16)   # temporarily use larger type
arr[0, 0, 0] = (arr[0, 0, 0] + 1) % 256
arr = arr.astype(np.uint8)    # back to 0–255 image

# Save modified image
modified_img = Image.fromarray(arr)
modified_img.save("bank_logo_modified.jpg")

# Check hashes
with open(r"C:\Users\divya\Downloads\team_25\team_25\static\bank_logo.jpg", "rb") as f:
    orig_hash = hashlib.sha256(f.read()).hexdigest()

with open("bank_logo_modified.jpg", "rb") as f:
    new_hash = hashlib.sha256(f.read()).hexdigest()

print("Original hash:", orig_hash)
print("Modified hash:", new_hash)
