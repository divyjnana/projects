from flask import Flask, render_template, request, redirect, url_for, session
import pandas as pd
import pickle
import os
from datetime import timedelta
import numpy as np
import shap

# --- FIX: Set Matplotlib Backend ---
# This MUST be done before importing pyplot
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
# --- END FIX ---

import io

# --- App Setup ---
app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = 'uploads'
app.config['SHAP_FOLDER'] = 'static/shap' # Folder to store plots
app.secret_key = 'dF83nLwq!uZkP@r7^b$X2sH9eM1#yVcQ'
app.permanent_session_lifetime = timedelta(minutes=30)

# Create folders if they don't exist
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
os.makedirs(app.config['SHAP_FOLDER'], exist_ok=True)

# --- Load Models and SHAP Explainer (at startup) ---
print("Loading models and initializing SHAP...")
# Load model, scaler, and encoders
model = pickle.load(open("credit_score_model.pkl", "rb"))
scaler = pickle.load(open("scaler.pkl", "rb"))
encoders = pickle.load(open("encoders.pkl", "rb"))

# Load SHAP info
model_info = pickle.load(open("model_info.pkl", "rb"))
model_name = model_info['model_name']
feature_names = model_info['feature_names']

# Load background data for SHAP
background_data_df = pd.read_pickle("shap_background_data.pkl")
# Sample background data for speed (e.g., 100 samples)
background_data_sample = shap.sample(background_data_df, 100)

# Initialize SHAP Explainer
explainer = shap.Explainer(model, background_data_sample)
print(f"SHAP Explainer initialized for {model_name}.")

# Use the feature names from the saved model info
REQUIRED_COLS = feature_names

# --- Routes ---

@app.route('/')
def home():
    return render_template("homepage.html")

@app.route('/login', methods=["POST"])
def login():
    username = request.form.get("username")
    password = request.form.get("password")
    if username == "admin" and password == "123":
        return redirect(url_for('creditscore'))
    else:
        return "Invalid credentials. Please try again.", 401

@app.route('/signup', methods=["POST"])
def signup():
    username = request.form.get("username")
    password = request.form.get("password")
    print(f"📝 New signup -> Username: {username}, Password: {password}")
    return redirect(url_for('creditscore'))

@app.route('/creditscore')
def creditscore():
    return render_template("creditscore.html")


@app.route('/predict', methods=["POST"])
def predict():
    
    # --- NEW: Helper Function for advice (Updated Logic) ---
    def generate_personalized_advice(shap_explanation, original_data, risk_level, feature_names):
        """Generates simple, actionable advice based on SHAP values."""
        
        # Combine feature names, their SHAP impact, and their original (real) values
        features_impact = list(zip(feature_names, shap_explanation.values, original_data.values))
        
        # --- Low Risk: Positive Reinforcement ---
        if risk_level == "Low Risk":
            pos_factors = sorted([f for f in features_impact if f[1] > 0], key=lambda x: x[1], reverse=True)
            if not pos_factors:
                return "Your stats look great! Your profile is strong and well-balanced."
            
            top_positive_name = pos_factors[0][0].replace('_', ' ')
            top_positive_val = pos_factors[0][2]
            # Format the value
            display_val = f"'{top_positive_val}'" if isinstance(top_positive_val, str) else f"{top_positive_val:,.0f}"
            
            return f"Your stats look great! Your profile is strong, primarily because your **{top_positive_name}** (at {display_val}) is excellent."

        # --- Medium & High Risk: Actionable Advice ---
        else:
            # Find the most negative factor
            neg_factors = sorted([f for f in features_impact if f[1] < -0.1], key=lambda x: x[1])
            if not neg_factors:
                return "Your profile is complex. Please review the detailed plot below to see all contributing factors."
            
            # Get data for the top negative factor
            top_negative_name, top_negative_impact, top_negative_val = neg_factors[0]
            
            # --- NEW Dynamic Advice Generator ---
            reason = ""
            advice = ""
            
            # Format the value for display
            display_val_str = f"'{top_negative_val}'" if isinstance(top_negative_val, str) else f"{top_negative_val:,.0f}"

            if top_negative_name == 'INCOME':
                reason = f"low income (currently {display_val_str})"
                advice = "The model sees this as a primary risk. **Increasing your income** would significantly improve your score."
            
            elif top_negative_name == 'INTEREST_RATE':
                reason = f"high interest rate (currently {top_negative_val}%)"
                advice = "This rate is high and is seen as risky. **Refinancing at a lower rate** would be very beneficial."
            
            elif top_negative_name == 'LOAN_AMOUNT':
                reason = f"high loan amount (currently {display_val_str})"
                advice = "This large loan amount is the biggest risk factor. **Reducing this amount** or showing a larger income would help."

            elif top_negative_name == 'NUM_OF_DEPENDENTS':
                reason = f"high number of dependents ({display_val_str})"
                advice = "Having many dependents can strain finances. This is a significant risk factor for the model."

            elif top_negative_name == 'EMPLOYMENT_STATUS':
                reason = f"employment status ({display_val_str})"
                advice = f"The model likely views this status as less stable than 'Employed'. **Securing full-time employment** (if '{top_negative_val}' is not 'Employed') could improve your score."
                
            elif top_negative_name == 'LOAN_TERM':
                reason = f"long loan term ({display_val_str} months)"
                advice = "Longer loan terms can be seen as higher risk. **Opting for a shorter term** might improve your score."

            else: # Generic fallback for AGE, MARITAL_STATUS, etc.
                reason = f"{top_negative_name.replace('_', ' ')} (currently {display_val_str})"
                advice = "This factor is negatively impacting your score. Please review the detailed plot for more information."
            
            # --- End Dynamic Advice ---

            potential_gain = abs(round(top_negative_impact, 2))
            summary = f"The main factor pulling your score down is your **{reason}**. {advice} Addressing this could potentially improve your score by around **{potential_gain} points**."
            
            if risk_level == "Medium Risk":
                summary = "You're on the right track. " + summary
            
            return summary
    # --- End of Helper Function ---

    try:
        if 'file' not in request.files:
            return "No file uploaded", 400
        file = request.files['file']
        
        if file.filename.endswith('.csv'):
            df = pd.read_csv(file)
        else:
            df = pd.read_excel(file)

        if not set(REQUIRED_COLS).issubset(df.columns):
            missing = list(set(REQUIRED_COLS) - set(df.columns))
            return f"Missing columns: {missing}", 400

        df_processed = df.copy() # We'll use the original 'df' later for advice

        # Encode categorical columns
        for col in df_processed.select_dtypes(include='object').columns:
            if col in encoders:
                le = encoders[col]
                df_processed[col] = df_processed[col].apply(lambda x: le.transform([x])[0] if x in le.classes_ else -1)
            else:
                df_processed[col] = df_processed[col].astype("category").cat.codes

        df_to_scale = df_processed[REQUIRED_COLS]
        scaled = scaler.transform(df_to_scale)
        preds = model.predict(scaled)

        # --- SHAP EXPLANATION ---
        print("Calculating SHAP values for new data...")
        scaled_df = pd.DataFrame(scaled, columns=feature_names)
        
        # Add check_additivity=False to fix the error
        shap_explanation = explainer(scaled_df, check_additivity=False)
        
        print("SHAP values calculated.")

        output = []
        plt.ioff() # This is still good practice

        for i, pred in enumerate(preds):
            score = round(pred, 2)
            if score >= 750:
                risk = "Low Risk"
                decision = "Likely Loan Approval"
            elif score >= 650:
                risk = "Medium Risk"
                decision = "Possible Approval with Caution"
            else:
                risk = "High Risk"
                decision = "Loan Likely Rejected. Try Budget Tracking."

            # --- GENERATE SHAP PLOT ---
            plot_filename = f"shap_person_{i+1}_{pd.Timestamp.now().strftime('%Y%m%d%H%M%S')}.png"
            plot_path_rel = f"shap/{plot_filename}" 
            plot_path_abs = os.path.join(app.config['SHAP_FOLDER'], plot_filename)
            
            row_explanation = shap_explanation[i]

            fig, ax = plt.subplots()
            shap.plots.waterfall(row_explanation, show=False)
            plt.savefig(plot_path_abs, bbox_inches='tight', dpi=100)
            plt.close(fig)
            
            # --- Generate Personalized Advice ---
            original_row = df.iloc[i][feature_names] # Get the original data for this person
            summary_text = generate_personalized_advice(row_explanation, original_row, risk, feature_names)
            # --- END ---

            output.append({
                "score": score,
                "risk": risk,
                "decision": decision,
                "shap_plot_url": url_for('static', filename=plot_path_rel),
                "summary_text": summary_text # Add the new summary text
            })

        session['prediction_result'] = output
        return redirect(url_for('analysis'))

    except Exception as e:
        print("🔥 SERVER ERROR:", str(e))
        return f"Server error: {str(e)}", 500

@app.route('/analysis')
def analysis():
    results = session.get('prediction_result')
    return render_template("analysis.html", results=results)

@app.route('/signup.html')
def budget_page():
    return render_template("budgettracking.html")

@app.route('/budget')
def budget():
    return render_template("budget.html")

@app.route('/clear_session')
def clear_session():
    results = session.get('prediction_result')
    if results:
        for entry in results:
            try:
                filename = entry['shap_plot_url'].split('/')[-1]
                plot_path = os.path.join(app.config['SHAP_FOLDER'], filename)
                if os.path.exists(plot_path):
                    os.remove(plot_path)
            except Exception as e:
                print(f"Could not delete plot: {e}")

    session.pop('prediction_result', None)
    return redirect(url_for('creditscore'))

if __name__ == '__main__':
    app.run(debug=True)