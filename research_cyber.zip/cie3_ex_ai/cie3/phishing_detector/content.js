// --- Whitelist with precomputed hashes ---
// IMPORTANT: Update these hashes using the [DEBUG] output from the browser itself
const WHITELIST = [
  {
    domain: "127.0.0.1:5000",
    includeSubdomains: false,
    logos: [
      { path: "/static/bank_logo.jpg", hash: "698ecf0f5d2513989ab56c80b15bf64efc4140170c4260ce63daf5174066890c" }
    ]
  },
  {
    domain: "www.mybank.com",
    includeSubdomains: false,
    logos: [
      { path: "/static/images/logo.png", hash: "998ecf0f5d2513989ab56c80b15bf64efc4140170c4260ce63daf5174066890c" }
    ]
  }
];

// --- Helper: get current host ---
function getCurrentHost() {
  return window.location.host;
}

// --- Helper: normalize paths ---
function getAbsolutePath(url) {
  try {
    const u = new URL(url, window.location.origin);
    return u.pathname;
  } catch {
    return null;
  }
}

// --- Hash helper ---
async function hashImage(url) {
  try {
    const resp = await fetch(url, { mode: "cors" });
    if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
    const buf = await resp.arrayBuffer();
    const digest = await crypto.subtle.digest("SHA-256", buf);
    return Array.from(new Uint8Array(digest))
      .map(b => b.toString(16).padStart(2, "0"))
      .join("");
  } catch (err) {
    console.warn("[DEBUG] Hashing failed for", url, err);
    return null;
  }
}

// --- Verify page logo against whitelist ---
async function pageHasWhitelistedLogo(allowedLogos) {
  console.log("[DEBUG] Checking allowed logos:", allowedLogos);

  const candidates = document.querySelectorAll("img");
  console.log("[DEBUG] Found images:", candidates.length);

  for (const img of candidates) {
    const path = getAbsolutePath(img.src);
    if (!path) continue;

    for (const { path: allowedPath, hash: trustedHash } of allowedLogos) {
      if (path === allowedPath || path.endsWith(allowedPath)) {
        console.log("[DEBUG] Path matched:", path);

        const imgHash = await hashImage(img.src);
        console.log("[DEBUG] Calculated hash:", imgHash);

        // 🚀 If whitelist hash is missing, log it so you can copy-paste
        if (!trustedHash || trustedHash === "PUT_BROWSER_HASH_HERE") {
          console.log(`[DEBUG] Paste this hash into WHITELIST for ${allowedPath}:`, imgHash);
        }

        if (imgHash && imgHash === trustedHash) {
          console.log("[DEBUG] ✅ Logo hash verified:", path);
          return true;
        } else {
          console.warn("[DEBUG] ❌ Hash mismatch for:", path);
        }
      }
    }
  }

  console.warn("[DEBUG] ❌ No logo passed validation.");
  return false;
}

// --- Find whitelist entry for current host ---
function findWhitelistEntry(host) {
  for (const entry of WHITELIST) {
    if (entry.domain === host) return entry;
    if (entry.includeSubdomains && host.endsWith("." + entry.domain)) {
      return entry;
    }
  }
  return null;
}

// --- Fake homoglyph detector (expand if needed) ---
function looksLikeHomoglyph(host) {
  return /xn--/.test(host); // IDN punycode marker
}

// --- Main ---
(async function main() {
  const host = getCurrentHost();
  console.log("[DEBUG] Current host:", host);

  if (looksLikeHomoglyph(host)) {
    alert("⚠️ Suspicious domain encoding detected. Proceed with caution.");
  }

  const entry = findWhitelistEntry(host);
  if (!entry) {
    alert("⚠️ This site is NOT in the trusted whitelist. Possible phishing!");
    return;
  }

  const ok = await pageHasWhitelistedLogo(entry.logos);
  if (!ok) {
    alert("⚠️ scam alert!! Possible phishing!");
  }

  // Watch for dynamically loaded logos
  const observer = new MutationObserver(async () => {
    if (await pageHasWhitelistedLogo(entry.logos)) {
      console.log("[DEBUG] ✅ Logo appeared later, stopping observer.");
      observer.disconnect();
    }
  });
  observer.observe(document.documentElement, { childList: true, subtree: true });
})();
