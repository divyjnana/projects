import pandas as pd
import shap
import pickle
import numpy as np
from flask import Flask, render_template
import matplotlib.pyplot as plt
import os
import base64
from io import BytesIO
import traceback

app = Flask(__name__)

# === File Paths ===
MODEL_PATH = "credit_score_model.pkl"
SCALER_PATH = "scaler.pkl"
ENCODERS_PATH = "encoders.pkl"
TEST_FILE = "test_data.csv"

# === Load trained artifacts ===
try:
    model = pickle.load(open(MODEL_PATH, "rb"))
    scaler = pickle.load(open(SCALER_PATH, "rb"))
    label_encoders = pickle.load(open(ENCODERS_PATH, "rb"))
    print("✅ Model, Scaler, and Encoders loaded successfully.")
except Exception as e:
    print(f"❌ Error loading model or encoders: {e}")
    raise


# === Preprocessing ===
def preprocess_input(df):
    df = df.copy()
    print("🧩 Starting preprocessing...")

    # Apply label encoders
    for col, le in label_encoders.items():
        if col in df.columns:
            df[col] = df[col].apply(lambda x: x if x in le.classes_ else le.classes_[0])
            df[col] = le.transform(df[col])
        else:
            print(f"⚠️ Missing column '{col}', adding default value 0.")
            df[col] = 0

    # Add missing numeric columns if any
    expected_cols = list(scaler.feature_names_in_)
    for col in expected_cols:
        if col not in df.columns:
            df[col] = 0
            print(f"⚠️ Added missing column: {col}")

    # Align to scaler’s expected feature order
    df = df[expected_cols]

    # Scale numeric data
    scaled = scaler.transform(df)
    print("✅ Preprocessing complete.")
    return pd.DataFrame(scaled, columns=expected_cols)


# === Risk classification logic ===
def classify_risk(score):
    if score >= 750:
        return "Low Risk"
    elif score >= 600:
        return "Medium Risk"
    else:
        return "High Risk"


# === SHAP Visualization ===
def plot_shap_values(explainer, X_sample, sample_index):
    try:
        shap_values = explainer(X_sample, check_additivity=False)
        plt.figure(figsize=(8, 4))
        shap.waterfall_plot(
            shap.Explanation(
                values=shap_values.values[sample_index],
                base_values=shap_values.base_values[sample_index],
                data=X_sample.iloc[sample_index],
                feature_names=X_sample.columns,
            )
        )
        buf = BytesIO()
        plt.tight_layout()
        plt.savefig(buf, format="png", bbox_inches="tight")
        plt.close()
        buf.seek(0)
        return "data:image/png;base64," + base64.b64encode(buf.read()).decode("utf-8")
    except Exception as e:
        print(f"⚠️ SHAP plot failed for index {sample_index}: {e}")
        print(traceback.format_exc())
        return None


# === Main route ===
@app.route('/')
def explain_predictions():
    if not os.path.exists(TEST_FILE):
        return "❌ Test file 'test_data.csv' not found. Please upload it first."

    df = pd.read_csv(TEST_FILE)

    if "CREDIT_SCORE" in df.columns:
        print("ℹ️ Dropping 'CREDIT_SCORE' column (target variable).")
        df = df.drop(columns=["CREDIT_SCORE"])

    print(f"📊 Loaded test data with shape: {df.shape}")

    try:
        X = preprocess_input(df)
    except Exception as e:
        print("❌ Preprocessing error:")
        print(traceback.format_exc())
        return f"Error preprocessing input: {e}"

    try:
        predictions = model.predict(X)
        if len(predictions.shape) > 1:
            predictions = predictions.ravel()
    except Exception as e:
        print("❌ Model prediction failed:")
        print(traceback.format_exc())
        return f"Prediction failed: {e}"

    # SHAP initialization with additivity disabled
    try:
        if hasattr(model, "estimators_"):  # Tree-based models
            explainer = shap.TreeExplainer(model, check_additivity=False)
        else:  # Other model types
            explainer = shap.Explainer(model, X, check_additivity=False)
        print("✅ SHAP explainer initialized successfully (additivity disabled).")
    except Exception as e:
        print("⚠️ SHAP explainer initialization failed, explanations will be skipped.")
        print(traceback.format_exc())
        explainer = None

    results = []
    for i in range(len(df)):
        score = round(float(predictions[i]), 2)
        risk = classify_risk(score)
        decision = (
            "Approved" if risk == "Low Risk"
            else "Review" if risk == "Medium Risk"
            else "Rejected"
        )

        shap_plot = None
        if explainer is not None:
            shap_plot = plot_shap_values(explainer, X, i)

        entry = {
            "score": score,
            "risk": risk,
            "decision": decision,
            "shap_plot": shap_plot,
            "dice_plot": None,
        }
        results.append(entry)

    print("✅ Predictions and SHAP explanations generated successfully.")
    return render_template("analysis.html", results=results)


if __name__ == '__main__':
    print("🚀 Starting Flask server (debug mode)...")
    app.run(debug=True)
